declare module 'fast-deep-equal' {
    const equal: (a: any, b: any) => boolean;
    export = equal;
}
