describe('less.js preProcessor Plugin', function() {
    testLessEqualsInDocument();
});
