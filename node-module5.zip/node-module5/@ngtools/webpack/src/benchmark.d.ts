export declare function time(label: string): void;
export declare function timeEnd(label: string): void;
