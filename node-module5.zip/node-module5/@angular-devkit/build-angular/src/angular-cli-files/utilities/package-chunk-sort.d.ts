export declare function generateEntryPoints(appConfig: any): string[];
export declare function packageChunkSort(appConfig: any): (left: any, right: any) => 1 | 0 | -1;
